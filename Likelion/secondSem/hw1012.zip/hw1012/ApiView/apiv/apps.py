from django.apps import AppConfig


class ApivConfig(AppConfig):
    name = 'apiv'
