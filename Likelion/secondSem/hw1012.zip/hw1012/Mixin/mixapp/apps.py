from django.apps import AppConfig


class MixappConfig(AppConfig):
    name = 'mixapp'
