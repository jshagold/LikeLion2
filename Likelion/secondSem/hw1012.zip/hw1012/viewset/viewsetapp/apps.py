from django.apps import AppConfig


class ViewsetappConfig(AppConfig):
    name = 'viewsetapp'
