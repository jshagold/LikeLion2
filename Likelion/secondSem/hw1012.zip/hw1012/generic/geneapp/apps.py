from django.apps import AppConfig


class GeneappConfig(AppConfig):
    name = 'geneapp'
