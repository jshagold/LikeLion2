from django.apps import AppConfig


class HwappConfig(AppConfig):
    name = 'hwapp'
