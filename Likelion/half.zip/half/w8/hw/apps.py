from django.apps import AppConfig


class HwConfig(AppConfig):
    name = 'hw'
